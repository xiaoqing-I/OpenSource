# Third-party (non-IBM) repositories

**This page is now at [https://ibmi-oss-docs.readthedocs.io/en/latest/yum/3RD_PARTY_REPOS.html](https://ibmi-oss-docs.readthedocs.io/en/latest/yum/3RD_PARTY_REPOS.html)**
