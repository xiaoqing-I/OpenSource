# RPM pile for IBM i releases in standard support

**This page is now at [https://ibmi-oss-docs.readthedocs.io/en/latest/yum/README.html](https://ibmi-oss-docs.readthedocs.io/en/latest/yum/README.html)**
