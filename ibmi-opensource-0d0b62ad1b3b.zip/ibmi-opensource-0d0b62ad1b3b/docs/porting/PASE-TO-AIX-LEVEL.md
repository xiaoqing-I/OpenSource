# Map PASE/IBM i Version to AIX Version

**This page is now at [https://ibmi-oss-docs.readthedocs.io/en/latest/PASE-TO-AIX-LEVEL.html](https://ibmi-oss-docs.readthedocs.io/en/latest/PASE-TO-AIX-LEVEL.html)**
