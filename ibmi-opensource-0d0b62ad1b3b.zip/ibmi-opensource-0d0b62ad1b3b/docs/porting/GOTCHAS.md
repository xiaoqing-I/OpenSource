# Gotchas When Building Software in PASE

**This page is now at [https://ibmi-oss-docs.readthedocs.io/en/latest/GOTCHAS.html](https://ibmi-oss-docs.readthedocs.io/en/latest/GOTCHAS.html)**