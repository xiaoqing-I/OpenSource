**This page is now at [https://ibmi-oss-docs.readthedocs.io/en/latest/PYTHON_PKGS_GUIDE.html](https://ibmi-oss-docs.readthedocs.io/en/latest/PYTHON_PKGS_GUIDE.html)**
