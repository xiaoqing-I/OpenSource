# Summary

**This page is now at [https://ibmi-oss-docs.readthedocs.io/en/latest/nginx.html](https://ibmi-oss-docs.readthedocs.io/en/latest/nginx.html)**
