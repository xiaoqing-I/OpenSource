# Guide to migrating from 5733-OPS to RPMs

**This page is now at [https://ibmi-oss-docs.readthedocs.io/en/latest/troubleshooting/5733OPS_MIGRATION.html](https://ibmi-oss-docs.readthedocs.io/en/latest/troubleshooting/5733OPS_MIGRATION.html)**
