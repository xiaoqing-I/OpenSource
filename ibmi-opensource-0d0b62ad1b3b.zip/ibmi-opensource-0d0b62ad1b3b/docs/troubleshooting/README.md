# Common Open Source Problems (and how to fix them)

**This page is now at [https://ibmi-oss-docs.readthedocs.io/en/latest/troubleshooting/README.html](https://ibmi-oss-docs.readthedocs.io/en/latest/troubleshooting/README.html)**
