# IBM i Open Source

**This repo has moved**

The docs are now at [https://ibmi-oss-docs.readthedocs.io/en/latest](https://ibmi-oss-docs.readthedocs.io/en/latest).
The repo is now at [https://github.com/IBM/ibmi-oss-docs](https://github.com/IBM/ibmi-oss-docs)
